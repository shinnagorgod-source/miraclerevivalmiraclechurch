@echo off
echo ============================================
echo  Miracle Church Revival Fellowship Website
echo ============================================
echo.
echo Starting the church website server...
echo.
echo Visit: http://127.0.0.1:8000
echo Admin:  http://127.0.0.1:8000/admin
echo         Username: admin
echo         Password: mrfc2024admin
echo.
echo Press Ctrl+C to stop the server.
echo.
call venv\Scripts\activate
python manage.py runserver
