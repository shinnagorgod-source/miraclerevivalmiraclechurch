import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mrfc_church.settings')
django.setup()
from django.contrib.auth import get_user_model
User = get_user_model()
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', 'admin@mrfc.com', 'mrfc2024admin')
    print('Admin user created: username=admin, password=mrfc2024admin')
else:
    print('Admin already exists')
