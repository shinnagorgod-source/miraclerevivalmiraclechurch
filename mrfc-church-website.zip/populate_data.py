﻿"""
Run this once to populate the MRFC website with all necessary sample data.
Usage: python populate_data.py
"""
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mrfc_church.settings')
django.setup()

from django.utils import timezone
from datetime import datetime, timedelta, date, time
from church.models import (
    Sermon, Announcement, Testimony, Event, Ministry,
    Staff, ServiceSchedule, PrayerRequest
)

print("Populating MRFC Church data...\n")

# ─── SERVICE SCHEDULES ────────────────────────────────────────────
ServiceSchedule.objects.all().delete()
schedules = [
    dict(day='Sunday', service_name='Morning Worship Service', time=time(9, 0), description='Main weekly worship and preaching', order=1),
    dict(day='Sunday', service_name='Sunday School (Children)', time=time(9, 0), description='For kids during the main service', order=2),
    dict(day='Sunday', service_name='Evening Worship Service', time=time(18, 0), description='Evening praise and Word', order=3),
    dict(day='Wednesday', service_name='Midweek Bible Study', time=time(19, 0), description='In-depth study of God\'s Word', order=4),
    dict(day='Friday', service_name='Prayer & Intercession Night', time=time(19, 30), description='Corporate prayer meeting', order=5),
    dict(day='Saturday', service_name='Youth Service', time=time(15, 0), description='Youth-led worship and ministry', order=6),
]
for s in schedules:
    ServiceSchedule.objects.get_or_create(day=s['day'], service_name=s['service_name'], defaults=s)
print(f"  [OK] {len(schedules)} Service Schedules created")

# ─── ANNOUNCEMENTS ─────────────────────────────────────────────────
Announcement.objects.all().delete()
announcements = [
    dict(title='Church Anniversary', body='Join us June 7 for our special Church Anniversary Revival Night! Everyone is welcome.', priority='high', is_active=True, start_date=date.today(), end_date=date(2026, 6, 7)),
    dict(title='Youth Camp Registration Now Open', body='Register for MRFC Youth Summer Camp 2026 (June 20-22). Limited slots only!', priority='normal', is_active=True, start_date=date.today(), end_date=date(2026, 6, 19)),
    dict(title='New Cell Groups Forming', body='We are forming new discipleship cell groups. Sign up at the Welcome Desk this Sunday.', priority='normal', is_active=True, start_date=date.today(), end_date=None),
    dict(title='Feeding Program Volunteers Needed', body='We need volunteers for our May 31 Community Feeding Program. Contact the church office.', priority='normal', is_active=True, start_date=date.today(), end_date=date(2026, 5, 31)),
]
for a in announcements:
    Announcement.objects.create(**a)
print(f"  [OK] {len(announcements)} Announcements created")

# ─── STAFF / LEADERSHIP ────────────────────────────────────────────
if Staff.objects.count() == 0:
    staff_members = [
        dict(name='Senior Pastor', title='Lead Pastor & Founder', bio='Called by God to lead Miracle Church Revival Fellowship with a heart for souls, revival, and the power of the Holy Spirit. Dedicated to seeing lives transformed by the grace of Jesus Christ.', email='pastor@mrfc.church', phone='+63 XXX XXX XXXX', order=1),
        dict(name='Associate Pastor', title='Associate Pastor & Youth Leader', bio='Passionate about raising up the next generation of Spirit-filled leaders. Committed to discipleship, evangelism, and seeing young people encounter God.', email='youth@mrfc.church', phone='', order=2),
        dict(name='Worship Director', title='Worship & Creative Arts Director', bio='Leading the church in anointed, God-focused worship every service. Believes that worship is a lifestyle that transforms the worshipper and glorifies God.', email='worship@mrfc.church', phone='', order=3),
        dict(name='Children\'s Church Leader', title='Children\'s Ministry Director', bio='Nurturing a love for Jesus in the hearts of the youngest members of MRFC. Dedicated to teaching children through fun, impactful, and biblically grounded programs.', email='children@mrfc.church', phone='', order=4),
        dict(name='Outreach Coordinator', title='Missions & Outreach Coordinator', bio='Overseeing the church\'s evangelism and community outreach programs, ensuring MRFC\'s impact extends beyond the church walls into the community and beyond.', email='outreach@mrfc.church', phone='', order=5),
        dict(name='Church Secretary', title='Administrative Secretary', bio='Keeping the ministry organized and running smoothly. The first point of contact for all church administrative needs and inquiries.', email='info@mrfc.church', phone='+63 XXX XXX XXXX', order=6),
    ]
    for s in staff_members:
        Staff.objects.create(**s)
    print(f"  [OK] {len(staff_members)} Staff members created")
else:
    print(f"  [i] Staff already exists ({Staff.objects.count()} records)")

# ─── MINISTRIES ────────────────────────────────────────────────────
if Ministry.objects.count() == 0:
    ministries = [
        dict(name='Worship Ministry', description='Leading the congregation in heartfelt, Spirit-filled praise and worship every service. We believe true worship transforms hearts, invites God\'s presence, and brings breakthrough. All musicians, singers, and creative individuals are welcome.', leader='Worship Director', schedule='Every Sunday & Special Events', icon='fa-music', order=1),
        dict(name='Youth Ministry (Generation Fire)', description='Empowering the next generation to encounter God, build their faith, and make a difference in the world. We run weekly services, camps, outreach events, and discipleship programs for youth aged 13-25.', leader='Associate Pastor', schedule='Every Saturday, 3:00 PM', icon='fa-fire', order=2),
        dict(name='Prayer Warriors', description='A dedicated team of intercessors standing in the gap for our church, nation, and the world. We believe in the power of fervent, persistent prayer and the authority of the believer in Christ Jesus.', leader='Prayer Ministry Head', schedule='Every Friday, 7:30 PM', icon='fa-hands-praying', order=3),
        dict(name='Women of God (WOG)', description='Equipping, empowering, and encouraging women to walk confidently in their God-given identity and purpose. We hold regular fellowships, retreats, and discipleship sessions in a warm, sisterhood environment.', leader="Women's Ministry Leader", schedule='Every Thursday, 5:00 PM', icon='fa-heart', order=4),
        dict(name="Men's Fellowship (Mighty Men)", description='Building godly brotherhood, accountability, and spiritual strength among the men of MRFC. We gather to study the Word, pray together, encourage one another, and grow as godly men, husbands, and fathers.', leader="Men's Ministry Head", schedule='Every Saturday, 7:00 AM', icon='fa-users', order=5),
        dict(name="Children's Ministry (Kingdom Kids)", description='Nurturing the faith of our youngest members aged 3-12 through biblically-grounded and age-appropriate teaching, worship, and activities. Every child matters to God and to MRFC.', leader="Children's Church Leader", schedule='Every Sunday during Morning Service', icon='fa-child', order=6),
        dict(name='Outreach & Missions', description='Taking the Gospel beyond our walls through feeding programs, medical missions, evangelism drives, and support of local and foreign missionaries. Every believer is called to be a witness for Christ.', leader='Outreach Coordinator', schedule='Monthly (various dates)', icon='fa-globe', order=7),
        dict(name='Discipleship & Cell Groups', description='Small group gatherings in homes and communities for deeper Bible study, fellowship, prayer, and spiritual growth. Find a cell group near your area and go deeper in your walk with God.', leader='Associate Pastor', schedule='Weekly (various locations & times)', icon='fa-book-bible', order=8),
    ]
    for m in ministries:
        Ministry.objects.create(**m)
    print(f"  [OK] {len(ministries)} Ministries created")
else:
    print(f"  [i] Ministries already exist ({Ministry.objects.count()} records)")

# ─── SERMONS ───────────────────────────────────────────────────────
if Sermon.objects.count() == 0:
    sermons = [
        dict(title='The Power of Resurrection Faith', speaker='Senior Pastor', category='faith', description='In this powerful message, we explore what it means to live with resurrection faith — the unshakeable confidence that the God who raised Jesus from the dead is actively working in our lives today. Discover how resurrection faith transforms your perspective, renews your hope, and empowers you to face every challenge with boldness and victory.', scripture_reference='Romans 8:11', date_preached=date(2026, 5, 11), is_featured=True, youtube_url=''),
        dict(title='When Prayer Moves Mountains', speaker='Senior Pastor', category='prayer', description='Jesus said that faith as small as a mustard seed can move mountains. This message unpacks the keys to a powerful, effective prayer life — and what it truly means to pray in faith without wavering. You will leave this message with renewed confidence to bring every need before God.', scripture_reference='Matthew 17:20 | James 5:16', date_preached=date(2026, 5, 4), is_featured=True, youtube_url=''),
        dict(title='Walk in the Spirit', speaker='Associate Pastor', category='worship', description='What does it mean to walk in the Spirit every single day — not just on Sundays? This sermon examines the fruit of the Spirit, the gifts of the Spirit, and how to stay continually filled and led by the Holy Spirit in every area of our daily lives.', scripture_reference='Galatians 5:16-25', date_preached=date(2026, 4, 27), is_featured=False, youtube_url=''),
        dict(title="God's Heart for the Lost", speaker='Senior Pastor', category='evangelism', description='We are all called to be witnesses for Christ. This message looks at God\'s passionate, relentless love for lost souls and our mandate to share the Good News with everyone around us — at work, at school, in our neighborhoods, and across the world.', scripture_reference='Luke 15:1-7 | Acts 1:8', date_preached=date(2026, 4, 20), is_featured=False, youtube_url=''),
        dict(title='The Family God Designed', speaker='Senior Pastor', category='family', description='God created the family as the foundational unit of society and the church. This message speaks directly to parents, spouses, and children about building a Christ-centered home filled with love, grace, the Word of God, and the presence of the Holy Spirit.', scripture_reference='Ephesians 5:22 - 6:4', date_preached=date(2026, 4, 13), is_featured=False, youtube_url=''),
        dict(title='He Still Heals Today', speaker='Associate Pastor', category='healing', description='Jesus Christ is the same yesterday, today, and forever — and that includes His miraculous healing power! This message builds faith for physical, emotional, and spiritual healing by anchoring us in God\'s unchanging promises and sharing real testimonies of divine healing.', scripture_reference='James 5:14-15 | Isaiah 53:5', date_preached=date(2026, 4, 6), is_featured=False, youtube_url=''),
        dict(title='Living a Life of Worship', speaker='Worship Director', category='worship', description='True worship goes far beyond songs on Sunday morning. This message explores what it means to offer our entire lives as living sacrifices — holy and pleasing to God. From how we work, to how we love, to how we serve — everything can be an act of worship.', scripture_reference='Romans 12:1-2 | John 4:23-24', date_preached=date(2026, 3, 29), is_featured=False, youtube_url=''),
        dict(title='Breakthrough is Coming', speaker='Senior Pastor', category='prophecy', description='A prophetic word for the church and nation: God is about to do something extraordinary among His people! This message is a call to align with what the Holy Spirit is doing in this season — a fresh wave of revival, signs, and wonders is at hand.', scripture_reference='Isaiah 43:19 | Joel 2:28-29', date_preached=date(2026, 3, 22), is_featured=True, youtube_url=''),
    ]
    for s in sermons:
        Sermon.objects.create(**s)
    print(f"  [OK] {len(sermons)} Sermons created")
else:
    print(f"  [i] Sermons already exist ({Sermon.objects.count()} records)")

# ─── EVENTS ────────────────────────────────────────────────────────
if Event.objects.count() == 0:
    now = timezone.now()
    events = [
        dict(title='MRFC Church Anniversary & Revival Night', description='Join us as we celebrate another year of God\'s faithfulness to Miracle Church Revival Fellowship! This special night of worship, testimonies, and powerful preaching will stir your heart and remind you of all God has done.\n\nExpect anointed music, moving testimonies, a special message, and a time of prayer and healing. Invite your friends and family — it\'s going to be an unforgettable night of revival!', location='MRFC Main Sanctuary', start_date=now.replace(2026, 6, 7, 18, 0, 0), end_date=now.replace(2026, 6, 7, 21, 0, 0), is_featured=True, livestream_url=''),
        dict(title='Youth Summer Camp 2026 — "Set on Fire"', description='A transformational 3-day, 2-night camp experience for youth aged 13-25!\n\nExpect powerful worship, life-changing talks, team-building games, campfire fellowship, and personal encounters with God. This is more than just a camp — it\'s a God encounter that will set your faith on fire for the rest of the year.\n\nRegistration required. Slots are limited — sign up at the Welcome Desk!', location='MRFC Youth Camp Grounds', start_date=now.replace(2026, 6, 20, 8, 0, 0), end_date=now.replace(2026, 6, 22, 17, 0, 0), is_featured=True, livestream_url=''),
        dict(title='Community Feeding Program', description='In the spirit of Christ\'s command to love our neighbors, MRFC will conduct a feeding program for underprivileged families and children in our community.\n\nVolunteers are warmly welcome! You can also donate goods, cooked food, or finances. Together, we can make a difference — one meal at a time.', location='Community Plaza near MRFC', start_date=now.replace(2026, 5, 31, 9, 0, 0), end_date=now.replace(2026, 5, 31, 13, 0, 0), is_featured=False, livestream_url=''),
        dict(title="Women's Conference — Daughters of the King", description='A powerful one-day conference dedicated to uplifting, empowering, and encouraging women of all ages in their faith, identity, and God-given purpose.\n\nFeaturing anointed guest speakers, heartfelt worship, interactive sessions, and a special panel discussion. Come expecting God to speak directly to your heart!', location='MRFC Main Hall', start_date=now.replace(2026, 7, 12, 8, 0, 0), end_date=now.replace(2026, 7, 12, 17, 0, 0), is_featured=False, livestream_url=''),
        dict(title="Men's Encounter Weekend — Mighty Men Rising", description='A weekend retreat exclusively for men — a time to get away from the noise of life, seek God, and be strengthened, healed, and renewed as godly men.\n\nActivities include morning devotionals, worship, a ropes course, breakout sessions on marriage, fatherhood, and purpose, and powerful prayer ministry.', location='MRFC Retreat Center', start_date=now.replace(2026, 8, 1, 8, 0, 0), end_date=now.replace(2026, 8, 2, 17, 0, 0), is_featured=False, livestream_url=''),
        dict(title='Easter Sunday Celebration', description='Celebrate the resurrection of Jesus Christ with the MRFC family! Our Easter Sunday service is one of the most anticipated events of the year — filled with powerful worship, a special Easter message, and time of communion.\n\nBring your family, invite your neighbors. He is Risen!', location='MRFC Main Sanctuary', start_date=now.replace(2026, 4, 5, 9, 0, 0), end_date=now.replace(2026, 4, 5, 12, 0, 0), is_featured=False, livestream_url=''),
    ]
    for e in events:
        Event.objects.create(**e)
    print(f"  [OK] {len(events)} Events created")
else:
    print(f"  [i] Events already exist ({Event.objects.count()} records)")

# ─── TESTIMONIES ───────────────────────────────────────────────────
if Testimony.objects.count() == 0:
    testimonies = [
        dict(name='Maria S.', title='Healed from Chronic Illness', testimony='For 3 years I suffered from a chronic condition the doctors said had no cure. After prayer at MRFC and the laying on of hands, I went back for my check-up and the doctors found no trace of the illness. God is a miracle-working God! I am so grateful for this church family who believed with me in faith.', is_approved=True, is_featured=True),
        dict(name='Jonathan R.', title='Restored Marriage and Family', testimony='My marriage was on the brink of collapse. We had given up on each other. But through the counseling and prayers of our pastors at MRFC, and through applying God\'s Word, our marriage was completely restored. Today we serve together in the church. What God restores, He restores better than before!', is_approved=True, is_featured=True),
        dict(name='Grace T.', title='Saved and Set Free from Addiction', testimony='I came to MRFC broken, addicted, and without hope. The love of this church and the power of the Gospel changed my life completely. I gave my life to Jesus, was baptized, and have been clean for 2 years. God really does save and set free — I am living proof!', is_approved=True, is_featured=True),
        dict(name='Samuel L.', title='Found Direction and Purpose', testimony='I was lost, purposeless, and drifting through life. After a friend invited me to MRFC, I encountered God in a real way. Through discipleship and the mentorship of the pastoral team, I found my calling. I now lead a cell group and am studying theology. God had a plan for me all along!', is_approved=True, is_featured=False),
    ]
    for t in testimonies:
        Testimony.objects.create(**t)
    print(f"  [OK] {len(testimonies)} Testimonies created")
else:
    print(f"  [i] Testimonies already exist ({Testimony.objects.count()} records)")

# ─── SAMPLE PRAYER REQUESTS (anonymized) ──────────────────────────
if PrayerRequest.objects.count() == 0:
    prayers = [
        dict(name='Anonymous', prayer_request='Please pray for complete healing for my mother who is in the hospital.', is_private=False, is_answered=False),
        dict(name='A Brother in Christ', prayer_request='Pray for my job situation — I need a breakthrough in my career and finances.', is_private=True, is_answered=False),
        dict(name='Sister M.', prayer_request='Thank God with me — my son finally came back to church after 5 years. God answers prayer!', is_private=False, is_answered=True),
    ]
    for p in prayers:
        PrayerRequest.objects.create(**p)
    print(f"  [OK] {len(prayers)} Sample Prayer Requests created")
else:
    print(f"  [i] Prayer Requests already exist")

print('\n[DONE] All data populated successfully!')
print('\nAdmin Summary:')
print(f'   Sermons:       {Sermon.objects.count()}')
print(f'   Events:        {Event.objects.count()}')
print(f'   Ministries:    {Ministry.objects.count()}')
print(f'   Staff:         {Staff.objects.count()}')
print(f'   Announcements: {Announcement.objects.count()}')
print(f'   Testimonies:   {Testimony.objects.count()}')
print(f'   Service Times: {ServiceSchedule.objects.count()}')
print(f'   Prayer Req:    {PrayerRequest.objects.count()}')
print('\nVisit: http://127.0.0.1:8000')
print('Admin: http://127.0.0.1:8000/admin  (admin / mrfc2024admin)')
