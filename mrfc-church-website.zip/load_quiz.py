import os, django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mrfc_church.settings')
django.setup()
from church.models import QuizQuestion

QuizQuestion.objects.all().delete()

questions = [

# ─── EASY (10) ────────────────────────────────────────────────────
dict(difficulty='easy', order=1,
    question='Who built a large ark to save his family and the animals from a great flood?',
    choice_a='Moses', choice_b='Noah', choice_c='Abraham', choice_d='David',
    correct_answer='B',
    explanation='God commanded Noah to build the ark because of Noah\'s faithfulness.',
    scripture_reference='Genesis 6:14'),

dict(difficulty='easy', order=2,
    question='What is the first book of the Bible?',
    choice_a='Exodus', choice_b='Psalms', choice_c='Genesis', choice_d='Matthew',
    correct_answer='C',
    explanation='Genesis means "beginning" and tells the story of creation and the early history of mankind.',
    scripture_reference='Genesis 1:1'),

dict(difficulty='easy', order=3,
    question='How many disciples did Jesus choose?',
    choice_a='7', choice_b='10', choice_c='12', choice_d='14',
    correct_answer='C',
    explanation='Jesus chose 12 disciples to be His closest followers and to carry on His ministry.',
    scripture_reference='Matthew 10:1-4'),

dict(difficulty='easy', order=4,
    question='Who was swallowed by a great fish?',
    choice_a='Elijah', choice_b='Jonah', choice_c='Isaiah', choice_d='Ezekiel',
    correct_answer='B',
    explanation='Jonah was swallowed by a great fish after he tried to flee from God\'s command to go to Nineveh.',
    scripture_reference='Jonah 1:17'),

dict(difficulty='easy', order=5,
    question='In which city was Jesus born?',
    choice_a='Jerusalem', choice_b='Nazareth', choice_c='Bethlehem', choice_d='Jericho',
    correct_answer='C',
    explanation='Jesus was born in Bethlehem of Judea, fulfilling the prophecy in Micah 5:2.',
    scripture_reference='Matthew 2:1'),

dict(difficulty='easy', order=6,
    question='Who was the first man created by God?',
    choice_a='Abel', choice_b='Cain', choice_c='Noah', choice_d='Adam',
    correct_answer='D',
    explanation='God formed Adam from the dust of the ground and breathed life into him.',
    scripture_reference='Genesis 2:7'),

dict(difficulty='easy', order=7,
    question='What did God create on the very first day?',
    choice_a='Animals', choice_b='Light', choice_c='Sky', choice_d='Water',
    correct_answer='B',
    explanation='God said "Let there be light" and there was light on the first day of creation.',
    scripture_reference='Genesis 1:3'),

dict(difficulty='easy', order=8,
    question='For how many days and nights did it rain during Noah\'s flood?',
    choice_a='7', choice_b='20', choice_c='40', choice_d='100',
    correct_answer='C',
    explanation='It rained for 40 days and 40 nights, flooding the entire earth.',
    scripture_reference='Genesis 7:12'),

dict(difficulty='easy', order=9,
    question='What river was Jesus baptized in?',
    choice_a='Nile', choice_b='Euphrates', choice_c='Jordan', choice_d='Tigris',
    correct_answer='C',
    explanation='John the Baptist baptized Jesus in the Jordan River.',
    scripture_reference='Matthew 3:13'),

dict(difficulty='easy', order=10,
    question='Who was the mother of Jesus?',
    choice_a='Martha', choice_b='Mary Magdalene', choice_c='Elizabeth', choice_d='Mary',
    correct_answer='D',
    explanation='Mary, a virgin, was chosen by God to be the mother of Jesus Christ.',
    scripture_reference='Luke 1:30-31'),

# ─── NORMAL (10) ──────────────────────────────────────────────────
dict(difficulty='normal', order=1,
    question='Who was the first king of Israel?',
    choice_a='David', choice_b='Solomon', choice_c='Saul', choice_d='Samuel',
    correct_answer='C',
    explanation='Saul was anointed by the prophet Samuel as the first king of Israel.',
    scripture_reference='1 Samuel 10:1'),

dict(difficulty='normal', order=2,
    question='How many books are in the New Testament?',
    choice_a='22', choice_b='27', choice_c='31', choice_d='39',
    correct_answer='B',
    explanation='The New Testament contains 27 books, from Matthew to Revelation.',
    scripture_reference=''),

dict(difficulty='normal', order=3,
    question='Who denied Jesus three times before the rooster crowed?',
    choice_a='Judas', choice_b='Thomas', choice_c='John', choice_d='Peter',
    correct_answer='D',
    explanation='Peter denied knowing Jesus three times on the night of Jesus\'s arrest, exactly as Jesus had predicted.',
    scripture_reference='Matthew 26:34'),

dict(difficulty='normal', order=4,
    question='What miracle did Jesus perform at the wedding in Cana?',
    choice_a='Healed the blind', choice_b='Raised the dead', choice_c='Turned water into wine', choice_d='Fed 5000 people',
    correct_answer='C',
    explanation='Turning water into wine at Cana was Jesus\'s first recorded miracle.',
    scripture_reference='John 2:1-11'),

dict(difficulty='normal', order=5,
    question='Who was thrown into the lions\' den?',
    choice_a='Ezekiel', choice_b='Daniel', choice_c='Elijah', choice_d='Jeremiah',
    correct_answer='B',
    explanation='Daniel was thrown into the lions\' den but God shut the lions\' mouths and he was unharmed.',
    scripture_reference='Daniel 6:16'),

dict(difficulty='normal', order=6,
    question='What is the shortest verse in the Bible?',
    choice_a='"Pray always."', choice_b='"God is love."', choice_c='"Jesus wept."', choice_d='"Fear not."',
    correct_answer='C',
    explanation='"Jesus wept" (John 11:35) is the shortest verse in the Bible, showing Jesus\'s humanity and compassion.',
    scripture_reference='John 11:35'),

dict(difficulty='normal', order=7,
    question='What did Jesus use to feed 5,000 people?',
    choice_a='10 loaves and 5 fish', choice_b='7 loaves and 3 fish', choice_c='5 loaves and 2 fish', choice_d='2 loaves and 7 fish',
    correct_answer='C',
    explanation='A boy gave Jesus 5 loaves of bread and 2 fish, which Jesus multiplied to feed over 5,000 people.',
    scripture_reference='John 6:9-13'),

dict(difficulty='normal', order=8,
    question='Who wrote most of the Psalms?',
    choice_a='Solomon', choice_b='Moses', choice_c='David', choice_d='Asaph',
    correct_answer='C',
    explanation='King David wrote about 73 of the 150 Psalms, making him the primary author.',
    scripture_reference='Psalm 23 (a Psalm of David)'),

dict(difficulty='normal', order=9,
    question='Who replaced Judas Iscariot as an apostle?',
    choice_a='Paul', choice_b='Barnabas', choice_c='Stephen', choice_d='Matthias',
    correct_answer='D',
    explanation='Matthias was chosen by lot to replace Judas Iscariot among the twelve apostles.',
    scripture_reference='Acts 1:26'),

dict(difficulty='normal', order=10,
    question='On which day did Jesus rise from the dead?',
    choice_a='The first day of the week', choice_b='The Sabbath', choice_c='The third day after Friday', choice_d='Both A and C',
    correct_answer='D',
    explanation='Jesus rose early on the first day of the week (Sunday), which was the third day after His crucifixion.',
    scripture_reference='Matthew 28:1 | 1 Corinthians 15:4'),

# ─── HARD (10) ────────────────────────────────────────────────────
dict(difficulty='hard', order=1,
    question='Who was the father of John the Baptist?',
    choice_a='Joseph', choice_b='Zacharias', choice_c='Simeon', choice_d='Aaron',
    correct_answer='B',
    explanation='Zacharias (Zechariah) was a priest and the father of John the Baptist. An angel appeared to him in the temple.',
    scripture_reference='Luke 1:13'),

dict(difficulty='hard', order=2,
    question='What was the name of Abraham\'s original hometown?',
    choice_a='Canaan', choice_b='Babylon', choice_c='Ur of the Chaldeans', choice_d='Haran',
    correct_answer='C',
    explanation='Abraham was originally from Ur of the Chaldeans before God called him to leave for the promised land.',
    scripture_reference='Genesis 11:31'),

dict(difficulty='hard', order=3,
    question='How many chapters are in the book of Psalms?',
    choice_a='100', choice_b='120', choice_c='150', choice_d='175',
    correct_answer='C',
    explanation='The book of Psalms has 150 chapters, making it the longest book in the Bible.',
    scripture_reference='Psalm 150'),

dict(difficulty='hard', order=4,
    question='What was the name of Moses\'s father-in-law?',
    choice_a='Hobab', choice_b='Aaron', choice_c='Caleb', choice_d='Jethro',
    correct_answer='D',
    explanation='Jethro (also called Reuel) was the priest of Midian and the father-in-law of Moses.',
    scripture_reference='Exodus 3:1'),

dict(difficulty='hard', order=5,
    question='Which apostle was a tax collector before following Jesus?',
    choice_a='Luke', choice_b='Matthew', choice_c='Mark', choice_d='John',
    correct_answer='B',
    explanation='Matthew (also called Levi) was a tax collector whom Jesus called to be His disciple.',
    scripture_reference='Matthew 9:9'),

dict(difficulty='hard', order=6,
    question='In which city were Paul and Silas imprisoned and sang hymns at midnight?',
    choice_a='Corinth', choice_b='Ephesus', choice_c='Antioch', choice_d='Philippi',
    correct_answer='D',
    explanation='Paul and Silas were imprisoned in Philippi. They prayed and sang hymns, and God sent an earthquake to open the prison doors.',
    scripture_reference='Acts 16:25-26'),

dict(difficulty='hard', order=7,
    question='What was the name of the garden where Jesus was arrested?',
    choice_a='Garden of Eden', choice_b='Garden of Gethsemane', choice_c='Mount of Olives Garden', choice_d='Garden of Joseph',
    correct_answer='B',
    explanation='Jesus went to the Garden of Gethsemane to pray before He was betrayed by Judas and arrested.',
    scripture_reference='Matthew 26:36'),

dict(difficulty='hard', order=8,
    question='Who was King Saul\'s father?',
    choice_a='Jesse', choice_b='Ner', choice_c='Kish', choice_d='Abner',
    correct_answer='C',
    explanation='Kish was the father of King Saul, from the tribe of Benjamin.',
    scripture_reference='1 Samuel 9:1-2'),

dict(difficulty='hard', order=9,
    question='What is the last word in the entire Bible?',
    choice_a='Hallelujah', choice_b='Forever', choice_c='Christ', choice_d='Amen',
    correct_answer='D',
    explanation='The Bible ends with the word "Amen" in Revelation 22:21.',
    scripture_reference='Revelation 22:21'),

dict(difficulty='hard', order=10,
    question='Who was the first judge of Israel mentioned by name in the book of Judges?',
    choice_a='Gideon', choice_b='Samson', choice_c='Othniel', choice_d='Deborah',
    correct_answer='C',
    explanation='Othniel, the son of Kenaz, was the first judge of Israel. He delivered Israel from Cushan-Rishathaim.',
    scripture_reference='Judges 3:9'),

# ─── EXPERT (10) ──────────────────────────────────────────────────
dict(difficulty='expert', order=1,
    question='What were the names of Moses\'s parents?',
    choice_a='Amram and Jochebed', choice_b='Levi and Miriam', choice_c='Aaron and Elisheba', choice_d='Kohath and Deborah',
    correct_answer='A',
    explanation='Moses\'s father was Amram and his mother was Jochebed, both from the tribe of Levi.',
    scripture_reference='Exodus 6:20'),

dict(difficulty='expert', order=2,
    question='Which Old Testament prophet specifically predicted that Jesus would be born of a virgin?',
    choice_a='Jeremiah', choice_b='Ezekiel', choice_c='Isaiah', choice_d='Micah',
    correct_answer='C',
    explanation='Isaiah prophesied: "Behold, a virgin shall conceive and bear a son, and shall call his name Immanuel."',
    scripture_reference='Isaiah 7:14'),

dict(difficulty='expert', order=3,
    question='Who was the high priest who presided at Jesus\'s trial before the Sanhedrin?',
    choice_a='Annas', choice_b='Caiaphas', choice_c='Ananias', choice_d='Eli',
    correct_answer='B',
    explanation='Caiaphas was the high priest that year and led the Sanhedrin council that condemned Jesus to death.',
    scripture_reference='Matthew 26:57'),

dict(difficulty='expert', order=4,
    question='Who was the mother of King Solomon?',
    choice_a='Abigail', choice_b='Ahinoam', choice_c='Michal', choice_d='Bathsheba',
    correct_answer='D',
    explanation='Bathsheba was the wife of David and the mother of Solomon, who became the wisest king of Israel.',
    scripture_reference='1 Kings 1:11-13'),

dict(difficulty='expert', order=5,
    question='What is the name of the blind man healed by Jesus near Jericho who is mentioned by name?',
    choice_a='Lazarus', choice_b='Bartimaeus', choice_c='Zacchaeus', choice_d='Siloam',
    correct_answer='B',
    explanation='Bartimaeus, son of Timaeus, cried out "Jesus, Son of David, have mercy on me!" and was healed by his faith.',
    scripture_reference='Mark 10:46'),

dict(difficulty='expert', order=6,
    question='In which epistle does Paul list the armor of God?',
    choice_a='Romans', choice_b='Colossians', choice_c='Ephesians', choice_d='Philippians',
    correct_answer='C',
    explanation='Paul describes the full armor of God in Ephesians 6:10-18, including the belt of truth, breastplate of righteousness, and more.',
    scripture_reference='Ephesians 6:10-18'),

dict(difficulty='expert', order=7,
    question='How many years did the Israelites wander in the wilderness after leaving Egypt?',
    choice_a='20 years', choice_b='30 years', choice_c='40 years', choice_d='50 years',
    correct_answer='C',
    explanation='The Israelites wandered for 40 years in the wilderness as a consequence of their unbelief and disobedience.',
    scripture_reference='Numbers 14:33'),

dict(difficulty='expert', order=8,
    question='In the book of Revelation, what are the seven churches addressed in chapters 2 and 3? Which of these is NOT one of them?',
    choice_a='Ephesus', choice_b='Antioch', choice_c='Sardis', choice_d='Pergamum',
    correct_answer='B',
    explanation='The seven churches are Ephesus, Smyrna, Pergamum, Thyatira, Sardis, Philadelphia, and Laodicea. Antioch is not among them.',
    scripture_reference='Revelation 1:11'),

dict(difficulty='expert', order=9,
    question='Who carried Jesus\'s cross on the way to Golgotha?',
    choice_a='John the apostle', choice_b='Barabbas', choice_c='Simon of Cyrene', choice_d='Joseph of Arimathea',
    correct_answer='C',
    explanation='Simon of Cyrene was compelled by Roman soldiers to carry Jesus\'s cross on the road to Golgotha.',
    scripture_reference='Matthew 27:32'),

dict(difficulty='expert', order=10,
    question='What was the Hebrew name of the apostle Paul before his conversion?',
    choice_a='Barnabas', choice_b='Silas', choice_c='Saul', choice_d='Apollos',
    correct_answer='C',
    explanation='Paul was originally known as Saul of Tarsus. After his dramatic conversion on the road to Damascus, he became known as Paul.',
    scripture_reference='Acts 9:1-18'),
]

for q in questions:
    QuizQuestion.objects.create(**q)

print(f'Loaded {QuizQuestion.objects.count()} Bible quiz questions.')
for d in ['easy','normal','hard','expert']:
    c = QuizQuestion.objects.filter(difficulty=d).count()
    print(f'  {d.title():8s}: {c} questions')
